(() => {
  "use strict";
  const app = document.getElementById("app");
  const desktop = document.getElementById("desktop-ui");
  const consoleUI = document.getElementById("console-ui");
  const toConsole = document.getElementById("to-console");
  const toDesktop = document.getElementById("console-return");
  const overlay = document.getElementById("console-overlay");
  const overlayTitle = document.getElementById("console-panel-title");
  const overlayContent = document.getElementById("console-panel-content");
  const crumb = document.getElementById("crumb-current");
  const toast = document.getElementById("preview-toast");
  const pageNames = {
    dashboard: "Home", library: "Library", remoteplay: "Remote Play", performance: "Performance",
    streaming: "Streaming", networking: "Networking", controls: "Controls",
    patcher: "AI Patcher", settings: "Settings"
  };
  const settingsSections = {
    Appearance: {
      kicker: "INTERFACE", title: "Appearance", desc: "Tune the glass desktop and console experience.",
      rows: [["Interface theme","Choose a visual tone","Midnight glass"],["Accent color","Active selection and highlights","Aurora blue"],["Reduced motion","Use fewer animated transitions","toggle"],["Launch in desktop mode","Open the full workspace at startup","toggle"]]
    },
    General: {
      kicker: "APP BEHAVIOR", title: "General", desc: "Everyday behavior and host preferences.",
      rows: [["Start with Windows","Open NEXORA when you sign in","toggle"],["Minimize to tray","Keep the host available in the background","toggle"],["Language","Language used by this interface","English"],["Profile","Local display name","Ahmad"]]
    },
    Network: {
      kicker: "CONNECTIVITY", title: "Network", desc: "Connection behavior and relay preferences (demo values).",
      rows: [["Connection mode","Choose how the receiver finds this host","Automatic"],["Relay fallback","Use a relay when direct play is unavailable","toggle"],["Pairing code lifetime","Temporary code expiration","5 minutes"],["Trusted devices","Paired devices saved on this PC","0 devices"]]
    },
    Streaming: {
      kicker: "VIDEO & AUDIO", title: "Streaming", desc: "Set the stream profile to use when remote play is connected.",
      rows: [["Resolution","Video output preset","1080p · 60 FPS"],["Encoder","Choose an available video encoder","Hardware · Auto"],["Audio capture","Sound sent to the receiver","System default"],["Adaptive quality","Adjust to changing network conditions","toggle"]]
    },
    Updates: {
      kicker: "VERSIONS & RECOVERY", title: "Updates", desc: "Update controls are presented for review; no updater is connected.",
      rows: [["Update channel","Release stream","Stable"],["Current build","Installed prototype version","1.3.0 · UI preview"],["Check for updates","Button action is demo-only","Check now"],["Restore backup","Recovery flow is a visual preview","Choose file"]]
    },
    "Privacy & security": {
      kicker: "LOCAL PROTECTION", title: "Privacy & security", desc: "Security and privacy status shown as sample UI.",
      rows: [["Device authorization","Only approved receivers may connect","Preview"],["Signed sessions","Validate peer and session identity","Preview"],["Diagnostic logs","Local structured logs for troubleshooting","toggle"],["Stored identity","Host keypair state","Demo only"]]
    }
  };
  const qualityChoices = ["480p · 60 fps", "720p · 60 fps", "1080p · 60 fps", "1440p · 60 fps"];
  let toastTimer = null;
  let switchTimer = null;
  let selectedQuality = 2;
  let selectedGame = "Halo Infinite";
  let activeSettings = "Appearance";

  function showToast(message = "UI preview only — feature not connected") {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function showPage(page) {
    if (!pageNames[page]) return;
    document.querySelectorAll(".nav-item[data-page]").forEach(button => {
      const active = button.dataset.page === page;
      button.classList.toggle("active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    document.querySelectorAll(".page-view[data-view]").forEach(view => {
      view.classList.toggle("active", view.dataset.view === page);
    });
    crumb.textContent = pageNames[page];
    document.getElementById("desktop-content").scrollTop = 0;
  }

  function enterConsole() {
    clearTimeout(switchTimer);
    closeConsolePanel();
    desktop.style.display = "flex";
    desktop.classList.remove("mode-return");
    desktop.classList.add("mode-leave");
    consoleUI.classList.remove("mode-exit");
    consoleUI.classList.add("active");
    consoleUI.setAttribute("aria-hidden", "false");
    app.classList.remove("desktop-mode");
    app.classList.add("console-mode");
    toConsole?.setAttribute("aria-pressed", "true");
    toast.classList.remove("show");
    switchTimer = setTimeout(() => {
      desktop.style.display = "none";
      desktop.classList.remove("mode-leave");
    }, 440);
  }

  function enterDesktop() {
    clearTimeout(switchTimer);
    closeConsolePanel();
    consoleUI.classList.remove("mode-exit");
    consoleUI.classList.remove("active");
    consoleUI.setAttribute("aria-hidden", "true");
    desktop.style.display = "flex";
    desktop.classList.remove("mode-leave");
    desktop.classList.add("mode-return");
    app.classList.remove("console-mode");
    app.classList.add("desktop-mode");
    toConsole?.setAttribute("aria-pressed", "false");
    toast.classList.remove("show");
    switchTimer = setTimeout(() => desktop.classList.remove("mode-return"), 500);
  }

  function rowMarkup([label, description, value]) {
    const control = value === "toggle"
      ? `<button class="console-setting-toggle enabled" type="button" role="switch" aria-checked="true" aria-label="${label}"></button>`
      : `<button class="console-setting-select" type="button" data-setting-value="${value}" aria-label="${label}: ${value}">${value}<span aria-hidden="true">　⌄</span></button>`;
    return `<div class="console-setting-row"><span><b>${label}</b><small>${description}</small></span>${control}</div>`;
  }

  function renderSettingsSection(section) {
    activeSettings = settingsSections[section] ? section : "Appearance";
    const data = settingsSections[activeSettings];
    overlayTitle.textContent = "Settings";
    overlayContent.innerHTML = `<div class="console-settings-layout"><nav class="console-settings-nav" aria-label="Console settings">${Object.keys(settingsSections).map(name => `<button type="button" data-settings-tab="${name}" class="${name === activeSettings ? "active" : ""}"><svg aria-hidden="true"><use href="#${name === "Network" ? "i-network" : name === "Streaming" ? "i-stream" : name === "Updates" ? "i-download" : name === "Privacy & security" ? "i-shield" : name === "General" ? "i-sliders" : "i-monitor"}"/></svg>${name}</button>`).join("")}</nav><div class="console-settings-content"><span class="eyebrow-small">${data.kicker}</span><h3>${data.title}</h3><p>${data.desc}</p><div>${data.rows.map(rowMarkup).join("")}</div><p class="preview-note">These controls are interactive mockups only. No value is saved and no system service is contacted.</p></div></div>`;
  }

  function openConsolePanel(kind) {
    if (!overlay) return;
    overlay.removeAttribute("hidden");
    overlay.setAttribute("aria-hidden", "false");
    requestAnimationFrame(() => overlay.classList.add("open"));
    if (kind === "settings") {
      renderSettingsSection("Appearance");
      return;
    }
    if (kind === "updates") {
      overlayTitle.textContent = "Updates";
      overlayContent.innerHTML = `<div class="console-update-card"><span class="update-symbol"><svg><use href="#i-download"/></svg></span><div class="console-update-copy"><b>NEXORA is up to date</b><small>Prototype build 1.3.0 · update checks are not connected.</small></div><button class="console-action-button primary" type="button" data-demo-action="update">Check again</button></div><p class="preview-note">No update manifest is contacted and no files are downloaded or changed.</p>`;
      return;
    }
    if (kind === "quality") {
      overlayTitle.textContent = "Stream quality";
      overlayContent.innerHTML = `<div class="console-settings-content"><h3>Choose a picture profile</h3><p>Pick a quality preset for the visual preview. This does not change a real encoder.</p><div class="console-quality-options">${qualityChoices.map((label,index) => `<button type="button" class="${index === selectedQuality ? "active" : ""}" data-quality-choice="${index}"><b>${label.split(" · ")[0]}</b><small>${label.split(" · ")[1]} · preview</small></button>`).join("")}</div><p class="preview-note">Quality selection is remembered only until you refresh this page.</p></div>`;
      return;
    }
    if (kind === "stream") {
      overlayTitle.textContent = "Remote play";
      overlayContent.innerHTML = `<div class="console-stream-card"><div class="console-stream-head"><i class="status-dot"></i><div><b>Host ready · no active stream</b><p>Connect a receiver to start a session. This preview cannot pair or stream.</p></div></div><div class="console-stream-details"><div><small>HOST COMPUTER</small><b>ORION-DESKTOP</b></div><div><small>RECEIVER</small><b>Not connected</b></div><div><small>PAIRING PIN</small><b>482 731 · sample</b></div></div><button class="console-action-button primary" type="button" data-demo-action="pair">Pair a receiver</button><p class="preview-note">Pairing and session transport are intentionally not wired in this UI-only build.</p></div>`;
      return;
    }
    if (kind === "details") {
      overlayTitle.textContent = "Game details";
      const selected = document.querySelector(".console-cover.is-selected");
      const className = selected ? [...selected.classList].find(name => name.startsWith("cover-")) : "cover-god";
      overlayContent.innerHTML = `<div class="console-game-detail"><div class="console-detail-art ${className || "cover-god"}"></div><div class="console-detail-text"><span class="eyebrow-small">SELECTED FROM YOUR LIBRARY</span><h3>${selectedGame}</h3><p>Explore game details, platform information, and play history. This record is sample content for the interface preview.</p><div class="console-detail-tags"><span>Windows PC</span><span>Verified sample</span><span>Ready to play</span></div><button class="console-action-button primary" type="button" data-demo-action="launch">Play ${selectedGame}</button><p class="preview-note">Game launching is not connected in this UI-only build.</p></div></div>`;
      return;
    }
    renderSettingsSection("Appearance");
  }

  function closeConsolePanel() {
    if (!overlay) return;
    overlay.classList.remove("open");
    overlay.setAttribute("aria-hidden", "true");
    overlay.setAttribute("hidden", "");
  }

  function selectConsoleGame(button) {
    selectedGame = button.dataset.game || "Selected game";
    document.querySelectorAll(".console-cover").forEach(card => {
      const selected = card === button;
      card.classList.toggle("is-selected", selected);
      card.setAttribute("aria-pressed", String(selected));
    });
    const normalized = selectedGame.toUpperCase();
    const words = normalized.split(" ");
    const title = document.getElementById("console-game-title");
    if (title) {
      title.replaceChildren(document.createTextNode(words.slice(0, -1).join(" ") + " "));
      const last = document.createElement("span");
      last.textContent = words.at(-1) || "";
      title.append(last);
    }
    showToast(`${selectedGame} selected`);
  }

  function updateQuality(step) {
    selectedQuality = (selectedQuality + step + qualityChoices.length) % qualityChoices.length;
    const label = document.getElementById("console-quality-label");
    if (label) label.textContent = qualityChoices[selectedQuality];
    showToast(`Preview quality: ${qualityChoices[selectedQuality]}`);
  }

  function renderDesktopSettings(section) {
    const data = settingsSections[section] || settingsSections.Appearance;
    const buttons = document.querySelectorAll(".settings-nav button");
    buttons.forEach(button => button.classList.toggle("active", button.dataset.desktopSetting === data.title));
    const target = document.querySelector(".settings-content");
    if (!target) return;
    target.innerHTML = `<article class="panel glass setting-card"><div class="panel-head"><div><span class="eyebrow-small">${data.kicker}</span><h3>${data.title}</h3></div><span class="tiny-tag">PREVIEW</span></div>${data.rows.map(rowMarkup).join("")}<p class="preview-note">These controls are preview-only and do not save or change system behavior.</p></article><article class="panel glass setting-card"><div class="panel-head"><div><span class="eyebrow-small">MORE NEXORA PAGES</span><h3>Quick access</h3></div></div><div class="settings-shortcuts"><button type="button" data-page="performance">Performance dashboard</button><button type="button" data-page="networking">Network & security</button><button type="button" data-page="controls">Controller layouts</button><button type="button" data-page="patcher">AI Patcher</button></div></article>`;
  }

  toConsole?.addEventListener("click", enterConsole);
  toDesktop?.addEventListener("click", enterDesktop);
  document.addEventListener("click", event => {
    const pageButton = event.target.closest(".nav-item[data-page], [data-goto], .settings-shortcuts [data-page]");
    if (pageButton) {
      showPage(pageButton.dataset.page || pageButton.dataset.goto);
      if (pageButton.classList.contains("sidebar-anywhere")) showToast("Your games are ready to browse");
      return;
    }
    const pageAction = event.target.closest("[data-page]");
    if (pageAction && pageNames[pageAction.dataset.page]) {
      showPage(pageAction.dataset.page);
      return;
    }
    const consoleAction = event.target.closest("[data-console-panel]");
    if (consoleAction) {
      openConsolePanel(consoleAction.dataset.consolePanel);
      return;
    }
    const qualityStep = event.target.closest("[data-quality-step]");
    if (qualityStep) {
      updateQuality(Number(qualityStep.dataset.qualityStep));
      return;
    }
    const cover = event.target.closest(".console-cover[data-game]");
    if (cover) {
      selectConsoleGame(cover);
      return;
    }
    const closeButton = event.target.closest("[data-console-close]");
    if (closeButton) {
      closeConsolePanel();
      return;
    }
    const settingsTab = event.target.closest("[data-settings-tab]");
    if (settingsTab) {
      renderSettingsSection(settingsTab.dataset.settingsTab);
      return;
    }
    const qualityChoice = event.target.closest("[data-quality-choice]");
    if (qualityChoice) {
      selectedQuality = Number(qualityChoice.dataset.qualityChoice);
      document.querySelectorAll("[data-quality-choice]").forEach(button => button.classList.toggle("active", button === qualityChoice));
      const label = document.getElementById("console-quality-label");
      if (label) label.textContent = qualityChoices[selectedQuality];
      showToast(`Preview quality: ${qualityChoices[selectedQuality]}`);
      return;
    }
    const toggle = event.target.closest(".console-setting-toggle");
    if (toggle) {
      const enabled = toggle.classList.toggle("enabled");
      toggle.setAttribute("aria-checked", String(enabled));
      showToast(`${toggle.getAttribute("aria-label")} ${enabled ? "on" : "off"} · preview only`);
      return;
    }
    const settingValue = event.target.closest("[data-setting-value]");
    if (settingValue) {
      const options = {
        "Midnight glass":["Midnight glass","Aurora blue","Nebula violet"],
        "Aurora blue":["Aurora blue","Midnight glass","Nebula violet"],
        "Nebula violet":["Nebula violet","Midnight glass","Aurora blue"],
        "Automatic":["Automatic","Direct","Relay only"],
        "1080p · 60 FPS":["1080p · 60 FPS","720p · 60 FPS","1440p · 60 FPS"],
        "Hardware · Auto":["Hardware · Auto","Software · x264"],
        "System default":["System default","Headset microphone","No audio"],
        "5 minutes":["5 minutes","2 minutes","10 minutes"],
        "0 devices":["0 devices"],"English":["English","Spanish","French"],
        "Ahmad":["Ahmad","My PC"],"Stable":["Stable","Beta"],
        "Check now":["Check now"],"Choose file":["Choose file"],
        "Preview":["Preview"],"Demo only":["Demo only"]
      };
      const current = settingValue.dataset.settingValue;
      const choices = options[current] || [current];
      const next = choices[(choices.indexOf(current) + 1) % choices.length];
      settingValue.dataset.settingValue = next;
      settingValue.setAttribute("aria-label", `${settingValue.getAttribute("aria-label").split(":")[0]}: ${next}`);
      settingValue.childNodes[0].nodeValue = next;
      showToast(`${next} · preview only`);
      return;
    }
    const desktopSetting = event.target.closest("[data-desktop-setting]");
    if (desktopSetting) {
      renderDesktopSettings(desktopSetting.dataset.desktopSetting);
      return;
    }
    const demoAction = event.target.closest("[data-demo-action]");
    if (demoAction) {
      const messages = {update:"No update service is connected in this preview.",pair:"Pairing is not connected in this preview.",launch:"Game launch is not connected in this preview."};
      showToast(messages[demoAction.dataset.demoAction] || "Preview only");
      return;
    }
    const collapse = event.target.closest(".collapse-quick");
    if (collapse) {
      const quickCard = collapse.closest(".quick-card");
      const actions = quickCard?.querySelectorAll(".quick-action");
      const collapsed = quickCard?.classList.toggle("is-collapsed");
      actions?.forEach(action => action.hidden = Boolean(collapsed));
      collapse.textContent = collapsed ? "⌄" : "⌃";
      return;
    }
    const consolePlay = event.target.closest(".console-play");
    if (consolePlay) {
      showToast(`${selectedGame} · game launch is not connected`);
      return;
    }
    const consoleView = event.target.closest(".console-view");
    if (consoleView) {
      openConsolePanel("details");
      return;
    }
    const qualityOption = event.target.closest(".quality-option");
    if (qualityOption) {
      qualityOption.parentElement.querySelectorAll(".quality-option").forEach(item => item.classList.toggle("selected", item === qualityOption));
      showToast("Stream profile preview selected");
      return;
    }
    const layout = event.target.closest(".layout-choice");
    if (layout) {
      layout.parentElement.querySelectorAll(".layout-choice").forEach(item => item.classList.toggle("active", item === layout));
      showToast(`${layout.querySelector("b")?.textContent || "Layout"} selected · preview only`);
      return;
    }
    const settingTab = event.target.closest(".settings-nav button");
    if (settingTab) {
      renderDesktopSettings(settingTab.dataset.desktopSetting || settingTab.textContent.trim());
      return;
    }
    const goto = event.target.closest("[data-goto]");
    if (goto) {
      showPage(goto.dataset.goto);
      return;
    }
    const toastAction = event.target.closest("[data-toast]");
    if (toastAction) {
      showToast(toastAction.dataset.toast);
      return;
    }
    const previewAction = event.target.closest(".primary-action,.secondary-action,.outline-button,.tab-strip button,.filter-pill,.sort-pill,.library-card-info button,.range-tabs button,.mock-toggle,.accent-choices i,.window-controls button,.icon-button");
    if (previewAction) {
      if (previewAction.classList.contains("mock-toggle")) previewAction.classList.toggle("enabled");
      if (previewAction.matches(".accent-choices i")) {
        previewAction.parentElement.querySelectorAll("i").forEach(item => item.classList.toggle("selected-accent", item === previewAction));
      }
      if (previewAction.matches(".tab-strip button,.range-tabs button")) {
        previewAction.parentElement.querySelectorAll("button").forEach(item => item.classList.toggle("active", item === previewAction));
      }
      showToast("Preview control changed locally; nothing is saved.");
      event.preventDefault();
    }
  });

  overlay?.addEventListener("click", event => {
    if (event.target === overlay) closeConsolePanel();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      if (overlay && !overlay.hasAttribute("hidden")) closeConsolePanel();
      else if (consoleUI.classList.contains("active")) enterDesktop();
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      showToast("Quick find is a visual placeholder in this preview");
    }
  });

  document.querySelectorAll(".settings-nav button").forEach((button, index) => {
    button.dataset.desktopSetting = Object.keys(settingsSections)[index] || "Appearance";
  });
  document.querySelectorAll(".console-cover").forEach((button,index) => button.setAttribute("aria-pressed",String(index===0)));
})();
