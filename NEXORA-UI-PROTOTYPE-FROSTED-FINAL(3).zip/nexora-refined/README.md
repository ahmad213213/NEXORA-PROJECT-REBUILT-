# NEXORA UI Prototype — Refined Desktop + Console

A browser-runnable, UI-only mockup. The desktop home and sidebar follow the supplied NEXORA concept: frosted navigation, cinematic featured banner, clean cover-art tiles, a compact CPU/RAM glance, separate pages for Remote Play, AI Patcher, Streaming, Networking, Controls, Performance and Settings, a connected-host card, quick actions, and gamepad-layout promotion. The console retains its full-screen game-first identity, adds a PlayStation-style controller icon for the desktop switch, polished mode-transition animation, selectable games, and navigable console panels.

## Run

- **Windows:** double-click `run-preview.bat`.
- **Any modern browser:** open `index.html`.
- No installation, Node.js, internet access, or credentials required.

## Click through

- **Desktop sidebar:** Home, Library, Remote Play, AI Patcher, Streaming, Networking, Controls, Performance, and Settings.
- **Desktop quick actions:** Add Game, Gamepad Settings, Layout Editor, Network Settings.
- **Desktop Settings:** Appearance, General, Network, Streaming, Updates, and Privacy & security tabs, plus shortcuts to the other PC-focused screens.
- **Controller icon (desktop top-right):** switches to console mode; the icon has no visible text label.
- **Console game covers:** select a game; **View** opens its detail panel.
- **Console tiles:** Settings opens category tabs and preview controls; Updates opens an update panel; Quality arrows and the quality tile open selectable presets; Stream opens receiver/session details.
- **Return:** use the Desktop button in console mode or press Escape. Escape closes an open console panel first.

Settings controls, toggles, tabs, game selection, and quality choices respond locally so the screens can be reviewed. They do not save data, launch games, pair devices, request updates, access hardware, contact a server, or modify the original NEXORA app.

## Screenshots and files

- `preview-desktop.png` — updated desktop home, captured at the supplied concept's 1536×1024 reference size.
- `preview-console.png` — console home.
- `preview-settings.png` — console settings panel.
- `index.html`, `styles.css`, `refinement.css`, `app.js` — prototype source.
- The desktop controller button is icon-only; the settings modal and navigation use frosted glass surfaces and a larger system-friendly font.
- `assets/` — local artwork used by the preview.
- `PREVIEW-CHECKS.txt` — interaction and layout checks run for this revision.
